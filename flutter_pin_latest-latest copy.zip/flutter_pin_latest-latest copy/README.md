# flutter_pin_latest

A new Flutter project.
