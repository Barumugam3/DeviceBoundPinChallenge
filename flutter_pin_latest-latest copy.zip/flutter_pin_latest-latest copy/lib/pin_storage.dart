import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:pointycastle/export.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PinStorage {
  PinStorage._();

  static final PinStorage instance = PinStorage._();

  static const _pinHashKey = 'poc.pin.hash';
  static const _pinSaltKey = 'poc.pin.salt';

  Future<bool> isPinConfigured() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_pinHashKey) != null;
  }

  Future<void> storePin(String pin) async {
    final prefs = await SharedPreferences.getInstance();

    final salt = _randomBytes(16);
    final hash = _pbkdf2Hash(pin, salt);

    await prefs.setString(_pinHashKey, base64Encode(hash));
    await prefs.setString(_pinSaltKey, base64Encode(salt));
  }

  Future<bool> verifyPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();

    final saltB64 = prefs.getString(_pinSaltKey);
    final hashB64 = prefs.getString(_pinHashKey);
    if (saltB64 == null || hashB64 == null) return false;

    final salt = base64Decode(saltB64);
    final storedHash = base64Decode(hashB64);

    final hash = _pbkdf2Hash(pin, salt);
    if (hash.length != storedHash.length) return false;

    var equal = true;
    for (var i = 0; i < hash.length; i++) {
      if (hash[i] != storedHash[i]) {
        equal = false;
      }
    }
    return equal;
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_pinHashKey);
    await prefs.remove(_pinSaltKey);
  }

  List<int> _pbkdf2Hash(String pin, List<int> salt) {
    final derivator = PBKDF2KeyDerivator(HMac(SHA256Digest(), 64));
    derivator.init(Pbkdf2Parameters(
      Uint8List.fromList(salt),
      10000,
      32,
    ));
    final input = Uint8List.fromList(utf8.encode(pin));
    return derivator.process(input);
  }

  List<int> _randomBytes(int length) {
    final rnd = Random.secure();
    return List<int>.generate(length, (_) => rnd.nextInt(256));
  }
}
