import 'package:flutter/material.dart';

import 'pin_storage.dart';
import 'pin_setup_screen.dart';
import 'secure_action_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PinPocApp());
}

class PinPocApp extends StatefulWidget {
  const PinPocApp({Key? key}) : super(key: key);

  @override
  State<PinPocApp> createState() => _PinPocAppState();
}

class _PinPocAppState extends State<PinPocApp> {
  late Future<bool> _isPinSetFuture;

  @override
  void initState() {
    super.initState();
    _isPinSetFuture = PinStorage.instance.isPinConfigured();
  }

  Future<void> _resetAll() async {
    await PinStorage.instance.clearAll();
    setState(() {
      _isPinSetFuture = PinStorage.instance.isPinConfigured();
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PIN POC',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: FutureBuilder<bool>(
        future: _isPinSetFuture,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          final isPinSet = snapshot.data ?? false;

          if (!isPinSet) {
            return PinSetupScreen(
              onComplete: () {
                setState(() {
                  _isPinSetFuture = Future.value(true);
                });
              },
            );
          } else {
            return SecureActionScreen(onReset: _resetAll);
          }
        },
      ),
    );
  }
}
