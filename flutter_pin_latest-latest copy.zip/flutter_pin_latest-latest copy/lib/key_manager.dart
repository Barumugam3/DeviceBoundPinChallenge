import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:pointycastle/asn1/primitives/asn1_integer.dart';
import 'package:pointycastle/asn1/primitives/asn1_sequence.dart';
import 'package:pointycastle/export.dart';
import 'package:shared_preferences/shared_preferences.dart';

class KeyManager {
  KeyManager._();

  static final KeyManager instance = KeyManager._();

  static const _privateKeyKey = 'poc.ecdsa.private';
  static const _publicKeyKey = 'poc.ecdsa.public';

  Future<bool> hasKeyPair() async {
    final prefs = await SharedPreferences.getInstance();
    final priv = prefs.getString(_privateKeyKey);
    final pub = prefs.getString(_publicKeyKey);
    return priv != null && pub != null;
  }

  Future<void> generateAndStoreKeypair() async {
    final prefs = await SharedPreferences.getInstance();

    final domainParams = ECDomainParameters('prime256v1'); // P-256

    final keyGen = ECKeyGenerator();
    keyGen.init(
      ParametersWithRandom(
        ECKeyGeneratorParameters(domainParams),
        _secureRandom(),
      ),
    );

    final pair = keyGen.generateKeyPair();
    final privateKey = pair.privateKey as ECPrivateKey;
    final publicKey = pair.publicKey as ECPublicKey;

    final privBytes = _bigIntToBytes(privateKey.d!, 32);
    final pubBytes = publicKey.Q!.getEncoded(false); // 0x04 || X || Y

    await prefs.setString(_privateKeyKey, base64Encode(privBytes));
    await prefs.setString(_publicKeyKey, base64Encode(pubBytes));
  }

  Future<String> getPublicKeyBase64() async {
    final prefs = await SharedPreferences.getInstance();
    final pub = prefs.getString(_publicKeyKey);
    if (pub == null) {
      throw StateError('Public key not found. Call generateAndStoreKeypair() first.');
    }
    return pub;
  }

  Future<String> signBase64Challenge(String base64Challenge) async {
    final prefs = await SharedPreferences.getInstance();
    final privEncoded = prefs.getString(_privateKeyKey);
    if (privEncoded == null) {
      throw StateError('Private key not found. Call generateAndStoreKeypair() first.');
    }

    final privBytes = Uint8List.fromList(base64Decode(privEncoded));
    final d = _bytesToBigInt(privBytes);

    final domainParams = ECDomainParameters('prime256v1');
    final privateKey = ECPrivateKey(d, domainParams);

    // Use our own FortunaRandom instead of registry "Fortuna"
    final signer = Signer('SHA-256/ECDSA');
    signer.init(
      true,
      ParametersWithRandom(
        PrivateKeyParameter<ECPrivateKey>(privateKey),
        _secureRandom(),
      ),
    );

    final message = base64Decode(base64Challenge);
    final sig = signer.generateSignature(message) as ECSignature;

    final der = _encodeEcdsaDer(sig);
    return base64Encode(der);
  }

  Future<void> clearKeys() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_privateKeyKey);
    await prefs.remove(_publicKeyKey);
  }

  // ---------- helpers ----------

  SecureRandom _secureRandom() {
    final secureRandom = FortunaRandom();
    final seed = Uint8List(32);
    final random = Random.secure();
    for (var i = 0; i < seed.length; i++) {
      seed[i] = random.nextInt(256);
    }
    secureRandom.seed(KeyParameter(seed));
    return secureRandom;
  }

  Uint8List _encodeEcdsaDer(ECSignature sig) {
    final seq = ASN1Sequence();
    seq.add(ASN1Integer(sig.r));
    seq.add(ASN1Integer(sig.s));
    final bytes = seq.encode();
    return Uint8List.fromList(bytes);
  }

  Uint8List _bigIntToBytes(BigInt value, int length) {
    var hex = value.toRadixString(16);
    if (hex.length.isOdd) {
      hex = '0$hex';
    }
    final valueBytes = _hexToBytes(hex);
    final result = Uint8List(length);
    final start = length - valueBytes.length;
    result.setRange(start, length, valueBytes);
    return result;
  }

  Uint8List _hexToBytes(String hex) {
    final result = Uint8List(hex.length ~/ 2);
    for (var i = 0; i < hex.length; i += 2) {
      result[i ~/ 2] =
          int.parse(hex.substring(i, i + 2), radix: 16);
    }
    return result;
  }

  BigInt _bytesToBigInt(Uint8List bytes) {
    var result = BigInt.zero;
    for (final b in bytes) {
      result = (result << 8) | BigInt.from(b);
    }
    return result;
  }
}
