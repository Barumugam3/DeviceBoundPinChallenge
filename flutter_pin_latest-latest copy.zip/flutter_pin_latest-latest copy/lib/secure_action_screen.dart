import 'package:flutter/material.dart';

import 'pin_storage.dart';
import 'key_manager.dart';
import 'api_client.dart';

class SecureActionScreen extends StatefulWidget {
  final Future<void> Function() onReset;

  const SecureActionScreen({Key? key, required this.onReset}) : super(key: key);

  @override
  State<SecureActionScreen> createState() => _SecureActionScreenState();
}

class _SecureActionScreenState extends State<SecureActionScreen> {
  final TextEditingController _pinController = TextEditingController();
  String _status = 'Idle';
  bool _isBusy = false;

  @override
  void initState() {
    super.initState();
    ApiClient.instance.init();
  }

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  Future<void> _performSecureAction() async {
    final pin = _pinController.text;

    final ok = await PinStorage.instance.verifyPin(pin);
    if (!ok) {
      setState(() {
        _status = 'Invalid PIN';
      });
      return;
    }

    setState(() {
      _isBusy = true;
      _status = 'Requesting challenge...';
    });

    try {
      const customerId = '123456';
      final deviceId = ApiClient.instance.deviceId;
      const contextJson = '{"type":"PAYMENT","amount":1000,"currency":"AED"}';

      final challengeResp = await ApiClient.instance.getChallenge(
        customerId: customerId,
        deviceId: deviceId,
        contextJson: contextJson,
      );

      final signatureBase64 =
          await KeyManager.instance.signBase64Challenge(challengeResp.challenge);

      final verifyResp = await ApiClient.instance.verifyChallenge(
        customerId: customerId,
        deviceId: deviceId,
        challengeId: challengeResp.challengeId,
        signature: signatureBase64,
      );

      setState(() {
        _status = 'Success. Token: ${verifyResp.token}';
      });
    } catch (e) {
      setState(() {
        _status = 'Error: ${e.toString()}';
      });
    } finally {
      setState(() {
        _isBusy = false;
      });
    }
  }

  Future<void> _handleReset() async {
    await PinStorage.instance.clearAll();
    await KeyManager.instance.clearKeys();
    await widget.onReset();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Secure Action'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete_forever),
            tooltip: 'Reset PIN & Keys',
            onPressed: _handleReset,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Status: $_status'),
            const SizedBox(height: 16),
            TextField(
              controller: _pinController,
              decoration: const InputDecoration(
                labelText: 'Enter PIN',
              ),
              obscureText: true,
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _isBusy ? null : _performSecureAction,
              child: _isBusy
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Do Secure Action'),
            ),
          ],
        ),
      ),
    );
  }
}
