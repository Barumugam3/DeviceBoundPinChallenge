import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiClient {
  ApiClient._();

  static final ApiClient instance = ApiClient._();

  // For macOS + backend on same machine:
  final Uri _base = Uri.parse('http://127.0.0.1:8080');

  static const _deviceIdKey = 'poc.device.id';

  late String _cachedDeviceId;

  String get deviceId => _cachedDeviceId;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    var id = prefs.getString(_deviceIdKey);
    if (id == null) {
      id = DateTime.now().millisecondsSinceEpoch.toString();
      await prefs.setString(_deviceIdKey, id);
    }
    _cachedDeviceId = id;
    debugPrint('[ApiClient] DeviceId = $_cachedDeviceId');
  }

  Future<void> registerDevice({
    required String customerId,
    required String deviceId,
    required String publicKeyBase64,
  }) async {
    final uri = _base.replace(path: '/api/devices/register');
    final body = {
      'customerId': customerId,
      'deviceId': deviceId,
      'publicKey': publicKeyBase64,
    };
    debugPrint('[ApiClient] POST $uri');
    debugPrint('[ApiClient] Body: ${jsonEncode(body)}');

    try {
      final resp = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );
      debugPrint('[ApiClient] <-- ${resp.statusCode} ${resp.reasonPhrase}');
      debugPrint('[ApiClient] Response body: ${resp.body}');
      _check(resp);
    } catch (e) {
      debugPrint('[ApiClient] ERROR registerDevice: $e');
      rethrow;
    }
  }

  Future<ChallengeResponse> getChallenge({
    required String customerId,
    required String deviceId,
    String? contextJson,
  }) async {
    final uri = _base.replace(path: '/api/auth/challenge');
    final body = {
      'customerId': customerId,
      'deviceId': deviceId,
      'contextJson': contextJson,
    };
    debugPrint('[ApiClient] POST $uri');
    debugPrint('[ApiClient] Body: ${jsonEncode(body)}');

    try {
      final resp = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );
      debugPrint('[ApiClient] <-- ${resp.statusCode} ${resp.reasonPhrase}');
      debugPrint('[ApiClient] Response body: ${resp.body}');
      _check(resp);
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      return ChallengeResponse(
        challengeId: data['challengeId'] as String,
        challenge: data['challenge'] as String,
      );
    } catch (e) {
      debugPrint('[ApiClient] ERROR getChallenge: $e');
      rethrow;
    }
  }

  Future<VerifyResponse> verifyChallenge({
    required String customerId,
    required String deviceId,
    required String challengeId,
    required String signature,
  }) async {
    final uri = _base.replace(path: '/api/auth/verify');
    final body = {
      'customerId': customerId,
      'deviceId': deviceId,
      'challengeId': challengeId,
      'signature': signature,
    };

    debugPrint('[ApiClient] POST $uri');
    debugPrint('[ApiClient] Body: ${jsonEncode(body)}');

    try {
      final resp = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );
      debugPrint('[ApiClient] <-- ${resp.statusCode} ${resp.reasonPhrase}');
      debugPrint('[ApiClient] Response body: ${resp.body}');
      _check(resp);
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      return VerifyResponse(
        status: data['status'] as String,
        token: data['token'] as String,
      );
    } catch (e) {
      debugPrint('[ApiClient] ERROR verifyChallenge: $e');
      rethrow;
    }
  }

  void _check(http.Response resp) {
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw Exception('HTTP ${resp.statusCode}: ${resp.body}');
    }
  }
}

class ChallengeResponse {
  final String challengeId;
  final String challenge;

  ChallengeResponse({required this.challengeId, required this.challenge});
}

class VerifyResponse {
  final String status;
  final String token;

  VerifyResponse({required this.status, required this.token});
}

Future<http.Response> testExternal() async {
  final uri = Uri.parse('https://jsonplaceholder.typicode.com/todos/1');
  debugPrint('[ApiClient] TEST GET $uri');
  return http.get(uri);
}

