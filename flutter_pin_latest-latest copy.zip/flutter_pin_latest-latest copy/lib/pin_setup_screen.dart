import 'package:flutter/material.dart';

import 'pin_storage.dart';
import 'key_manager.dart';
import 'api_client.dart';

class PinSetupScreen extends StatefulWidget {
  final VoidCallback onComplete;

  const PinSetupScreen({Key? key, required this.onComplete}) : super(key: key);

  @override
  State<PinSetupScreen> createState() => _PinSetupScreenState();
}

class _PinSetupScreenState extends State<PinSetupScreen> {
  final TextEditingController _pinController = TextEditingController();
  final TextEditingController _confirmPinController = TextEditingController();

  bool _isBusy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    ApiClient.instance.init();
  }

  @override
  void dispose() {
    _pinController.dispose();
    _confirmPinController.dispose();
    super.dispose();
  }

  Future<void> _savePin() async {
    final pin = _pinController.text;
    final confirm = _confirmPinController.text;

    if (pin.isEmpty || pin != confirm) {
      setState(() {
        _error = 'PINs do not match';
      });
      return;
    }

    setState(() {
      _isBusy = true;
      _error = null;
    });

    try {
      await PinStorage.instance.storePin(pin);
      await KeyManager.instance.generateAndStoreKeypair();
      final publicKeyBase64 = await KeyManager.instance.getPublicKeyBase64();

      const customerId = '123456';
      final deviceId = ApiClient.instance.deviceId;

      await ApiClient.instance.registerDevice(
        customerId: customerId,
        deviceId: deviceId,
        publicKeyBase64: publicKeyBase64,
      );

      if (mounted) {
        widget.onComplete();
      }
    } catch (e) {
      setState(() {
        _error = 'Error: ${e.toString()}';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isBusy = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Setup PIN'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _pinController,
              decoration: const InputDecoration(
                labelText: 'Enter PIN',
              ),
              obscureText: true,
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _confirmPinController,
              decoration: const InputDecoration(
                labelText: 'Confirm PIN',
              ),
              obscureText: true,
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 12),
            if (_error != null)
              Text(
                _error!,
                style: const TextStyle(color: Colors.red),
              ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _isBusy ? null : _savePin,
              child: _isBusy
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Save PIN & Register Device'),
            ),
          ],
        ),
      ),
    );
  }
}
