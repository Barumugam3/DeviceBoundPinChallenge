package com.example.pinbackend.service;

import com.example.pinbackend.dto.ChallengeRequest;
import com.example.pinbackend.dto.ChallengeResponse;
import com.example.pinbackend.dto.VerifyRequest;
import com.example.pinbackend.dto.VerifyResponse;
import com.example.pinbackend.entity.ChallengeEntity;
import com.example.pinbackend.entity.DeviceRegistration;
import com.example.pinbackend.repository.ChallengeRepository;
import com.example.pinbackend.repository.DeviceRegistrationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;

@Service
public class AuthService {

    private final DeviceRegistrationRepository deviceRepo;
    private final ChallengeRepository challengeRepo;
    private final CryptoService cryptoService;
    private final SecureRandom secureRandom = new SecureRandom();

    public AuthService(DeviceRegistrationRepository deviceRepo,
                       ChallengeRepository challengeRepo,
                       CryptoService cryptoService) {
        this.deviceRepo = deviceRepo;
        this.challengeRepo = challengeRepo;
        this.cryptoService = cryptoService;
    }

    @Transactional
    public void registerDevice(String customerId, String deviceId, String publicKey) {
        DeviceRegistration device = new DeviceRegistration();
        device.setCustomerId(customerId);
        device.setDeviceId(deviceId);
        device.setPublicKey(publicKey);
        deviceRepo.save(device);
    }

    @Transactional
    public ChallengeResponse createChallenge(ChallengeRequest request) {
        DeviceRegistration device = deviceRepo
                .findByCustomerIdAndDeviceIdAndStatus(request.getCustomerId(), request.getDeviceId(), "ACTIVE")
                .orElseThrow(() -> new IllegalArgumentException("Device not registered"));

        byte[] challengeBytes = new byte[32];
        secureRandom.nextBytes(challengeBytes);

        ChallengeEntity entity = new ChallengeEntity();
        entity.setCustomerId(device.getCustomerId());
        entity.setDeviceId(device.getDeviceId());
        entity.setChallenge(challengeBytes);
        entity.setContextJson(request.getContextJson());
        entity.setExpiresAt(Instant.now().plus(60, ChronoUnit.SECONDS));

        challengeRepo.save(entity);

        String challengeBase64 = Base64.getEncoder().encodeToString(challengeBytes);
        return new ChallengeResponse(entity.getId(), challengeBase64);
    }

    @Transactional
    public VerifyResponse verify(VerifyRequest request) {
        ChallengeEntity challenge = challengeRepo.findById(request.getChallengeId())
                .orElseThrow(() -> new IllegalArgumentException("Challenge not found"));

        if (challenge.isUsed() || challenge.getExpiresAt().isBefore(Instant.now())) {
            throw new IllegalStateException("Challenge expired or already used");
        }

        if (!challenge.getCustomerId().equals(request.getCustomerId()) ||
                !challenge.getDeviceId().equals(request.getDeviceId())) {
            throw new IllegalStateException("Challenge does not match device/customer");
        }

        DeviceRegistration device = deviceRepo
                .findByCustomerIdAndDeviceIdAndStatus(request.getCustomerId(), request.getDeviceId(), "ACTIVE")
                .orElseThrow(() -> new IllegalStateException("Device not active"));

        boolean ok = cryptoService.verifySignature(
                device.getPublicKey(),
                challenge.getChallenge(),
                request.getSignature()
        );

        if (!ok) {
            throw new IllegalStateException("Invalid signature");
        }

        challenge.setUsed(true);
        challengeRepo.save(challenge);

        return new VerifyResponse("OK", "DUMMY-TOKEN-" + challenge.getId());
    }
}
