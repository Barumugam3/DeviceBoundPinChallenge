package com.example.pinbackend.repository;

import com.example.pinbackend.entity.DeviceRegistration;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface DeviceRegistrationRepository extends JpaRepository<DeviceRegistration, String> {
    Optional<DeviceRegistration> findByCustomerIdAndDeviceIdAndStatus(String customerId, String deviceId, String status);
}
