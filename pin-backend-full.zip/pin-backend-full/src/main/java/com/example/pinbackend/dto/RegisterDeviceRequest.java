package com.example.pinbackend.dto;

import jakarta.validation.constraints.NotBlank;

public class RegisterDeviceRequest {

    @NotBlank
    private String customerId;

    @NotBlank
    private String deviceId;

    @NotBlank
    private String publicKey; // base64 uncompressed EC point

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public String getPublicKey() { return publicKey; }
    public void setPublicKey(String publicKey) { this.publicKey = publicKey; }
}
