package com.example.pinbackend.controller;

import com.example.pinbackend.dto.ChallengeRequest;
import com.example.pinbackend.dto.ChallengeResponse;
import com.example.pinbackend.dto.VerifyRequest;
import com.example.pinbackend.dto.VerifyResponse;
import com.example.pinbackend.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/challenge")
    public ResponseEntity<ChallengeResponse> challenge(@Valid @RequestBody ChallengeRequest request) {
        return ResponseEntity.ok(authService.createChallenge(request));
    }

    @PostMapping("/verify")
    public ResponseEntity<VerifyResponse> verify(@Valid @RequestBody VerifyRequest request) {
        return ResponseEntity.ok(authService.verify(request));
    }
}
