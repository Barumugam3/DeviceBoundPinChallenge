package com.example.pinbackend.dto;

import jakarta.validation.constraints.NotBlank;

public class ChallengeRequest {

    @NotBlank
    private String customerId;

    @NotBlank
    private String deviceId;

    private String contextJson;

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public String getContextJson() { return contextJson; }
    public void setContextJson(String contextJson) { this.contextJson = contextJson; }
}
