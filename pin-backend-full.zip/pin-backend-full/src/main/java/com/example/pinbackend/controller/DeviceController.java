package com.example.pinbackend.controller;

import com.example.pinbackend.dto.RegisterDeviceRequest;
import com.example.pinbackend.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/devices")
public class DeviceController {

    private final AuthService authService;

    public DeviceController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterDeviceRequest request) {
        authService.registerDevice(request.getCustomerId(), request.getDeviceId(), request.getPublicKey());
        return ResponseEntity.ok().body("{'status':'REGISTERED'}");
    }
}
