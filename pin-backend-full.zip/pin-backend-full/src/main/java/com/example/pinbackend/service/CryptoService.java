package com.example.pinbackend.service;

import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.security.*;
import java.security.spec.*;
import java.util.Arrays;
import java.util.Base64;

@Service
public class CryptoService {

    public boolean verifySignature(String base64PublicKey, byte[] challengeBytes, String base64Signature) {
        try {
            byte[] pubBytes = Base64.getDecoder().decode(base64PublicKey);
            // Expect uncompressed EC point: 0x04 || X(32) || Y(32) for P-256
            if (pubBytes.length != 65 || pubBytes[0] != 0x04) {
                throw new IllegalArgumentException("Invalid public key encoding");
            }

            byte[] xBytes = Arrays.copyOfRange(pubBytes, 1, 33);
            byte[] yBytes = Arrays.copyOfRange(pubBytes, 33, 65);

            AlgorithmParameters parameters = AlgorithmParameters.getInstance("EC");
            parameters.init(new ECGenParameterSpec("secp256r1"));
            ECParameterSpec ecParameters = parameters.getParameterSpec(ECParameterSpec.class);

            ECPoint ecPoint = new ECPoint(new BigInteger(1, xBytes), new BigInteger(1, yBytes));
            ECPublicKeySpec pubSpec = new ECPublicKeySpec(ecPoint, ecParameters);
            KeyFactory kf = KeyFactory.getInstance("EC");
            PublicKey publicKey = kf.generatePublic(pubSpec);

            Signature sig = Signature.getInstance("SHA256withECDSA");
            sig.initVerify(publicKey);
            sig.update(challengeBytes);

            byte[] signatureBytes = Base64.getDecoder().decode(base64Signature);
            return sig.verify(signatureBytes);
        } catch (Exception e) {
            return false;
        }
    }
}
