package com.example.pinbackend.repository;

import com.example.pinbackend.entity.ChallengeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChallengeRepository extends JpaRepository<ChallengeEntity, String> {
}
