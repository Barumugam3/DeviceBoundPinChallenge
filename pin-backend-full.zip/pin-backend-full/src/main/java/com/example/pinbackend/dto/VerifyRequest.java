package com.example.pinbackend.dto;

import jakarta.validation.constraints.NotBlank;

public class VerifyRequest {

    @NotBlank
    private String customerId;

    @NotBlank
    private String deviceId;

    @NotBlank
    private String challengeId;

    @NotBlank
    private String signature; // base64 DER-encoded ECDSA signature

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public String getChallengeId() { return challengeId; }
    public void setChallengeId(String challengeId) { this.challengeId = challengeId; }

    public String getSignature() { return signature; }
    public void setSignature(String signature) { this.signature = signature; }
}
