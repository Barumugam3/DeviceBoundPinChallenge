package com.example.pinbackend.dto;

public class ChallengeResponse {
    private String challengeId;
    private String challenge; // base64

    public ChallengeResponse(String challengeId, String challenge) {
        this.challengeId = challengeId;
        this.challenge = challenge;
    }

    public String getChallengeId() { return challengeId; }
    public void setChallengeId(String challengeId) { this.challengeId = challengeId; }

    public String getChallenge() { return challenge; }
    public void setChallenge(String challenge) { this.challenge = challenge; }
}
