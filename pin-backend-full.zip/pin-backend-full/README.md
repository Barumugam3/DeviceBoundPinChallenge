# PIN Backend POC (Spring Boot)

This project implements the server-side of the local-PIN + device-key + server-challenge flow.

## Tech

- Java 21
- Spring Boot 3.3.x
- H2 in-memory database
- REST APIs

## Endpoints

### Register device

POST /api/devices/register
Content-Type: application/json

{
  "customerId": "123456",
  "deviceId": "DEVICE-1",
  "publicKey": "<base64-of-uncompressed-EC-point-0x04XY>"
}

### Get challenge

POST /api/auth/challenge

{
  "customerId": "123456",
  "deviceId": "DEVICE-1",
  "contextJson": "{\"type\":\"PAYMENT\",\"amount\":1000}"
}

Response:

{
  "challengeId": "...",
  "challenge": "<base64-random-32-bytes>"
}

### Verify

POST /api/auth/verify

{
  "customerId": "123456",
  "deviceId": "DEVICE-1",
  "challengeId": "...",
  "signature": "<base64-DER-encoded-ECDSA-signature>"
}

If valid:

{
  "status": "OK",
  "token": "DUMMY-TOKEN-..."
}

## Run

```bash
mvn spring-boot:run
```

Server runs on http://localhost:8080
